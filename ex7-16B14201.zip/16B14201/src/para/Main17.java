package para;

/** スライダにより画像処理効果が変わるプログラム
 */

 public class Main17 extends Main15 {
     public Main17() {
         super("imagefilter.cl", "Filter3");
     }
 }