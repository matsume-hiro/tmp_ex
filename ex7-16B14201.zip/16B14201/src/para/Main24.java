package para;

/** スライダにより画像処理効果が変わるプログラム
 */

 public class Main24 extends Main15 {
     public Main24() {
         super("edge.cl", "Filter1");
     }
 }